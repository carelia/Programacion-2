﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaMuebleria
{
    public partial class Pantalla_hija_Categoria : Form
    {
        public Pantalla_hija_Categoria()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Añadir_Click(object sender, EventArgs e)
        {

        }
    }
}
