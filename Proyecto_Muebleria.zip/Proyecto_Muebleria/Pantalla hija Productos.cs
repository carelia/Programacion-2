﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaMuebleria
{
    public partial class Pantalla_hija : Form
    {
        public Pantalla_hija()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Pantalla_hija_Load(object sender, EventArgs e)
        {

        }
    }
}
