﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaMuebleria
{
    public partial class Pantalla_hija_Clientes : Form
    {
        public Pantalla_hija_Clientes()
        {
            InitializeComponent();
        }
    }
}
