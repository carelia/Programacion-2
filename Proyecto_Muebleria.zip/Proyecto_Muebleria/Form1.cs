﻿using SistemaMuebleria;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Muebleria
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            personalizardiseño();
        }
        private void personalizardiseño()
        {
            panelAdministracion.Visible = false;
            panelReportes.Visible = false;
        }
        private void escondersubmenu() 
        {
            if (panelAdministracion.Visible == true) 
                panelAdministracion.Visible = false;
            if (panelReportes.Visible == true)
                panelReportes.Visible = false;
        }
        private void showSubMenu(Panel submenu) 
        {
            if (submenu.Visible == false)
            {
                escondersubmenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }
        private Form FormularioActivo = null;
        private void abrirFormularios(Form formularioHijo) 
        {
            if (FormularioActivo != null)
                FormularioActivo.Close();
            FormularioActivo = formularioHijo;
            formularioHijo.TopLevel = false; //establece un valor que indica si se muestra el formulario
            formularioHijo.FormBorderStyle = FormBorderStyle.None; //quita el borde del formulario
            formularioHijo.Dock = DockStyle.Fill; // determina cómo se cambia el tamaño de un control con el de su control primario.
            panelFormularios.Controls.Add(formularioHijo);
            panelFormularios.Tag = formularioHijo;
            formularioHijo.BringToFront(); //Lleva el control al frente del orden z.
            formularioHijo.Show();//muestra el formulario
        }
        private void btnAdministracion_Click(object sender, EventArgs e)
        {
            showSubMenu(panelAdministracion);
        }

        private void btnCaja_Click(object sender, EventArgs e)
        {
            abrirFormularios(new Pantalla_hija_Clientes());
            escondersubmenu();
        }

        private void btnCompras_Click(object sender, EventArgs e)
        {
            abrirFormularios(new Pantalla_hija_ventas());
            escondersubmenu();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            showSubMenu(panelReportes);
        }

        private void btnReporteVentas_Click(object sender, EventArgs e)
        {
            escondersubmenu();
        }

        private void btnReporteProductos_Click(object sender, EventArgs e)
        {
            escondersubmenu();
        }

        private void panelFormularios_Paint(object sender, PaintEventArgs e)
        {

        }

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnProveedores_Click(object sender, EventArgs e)
        {
            abrirFormularios(new Pantalla_hija_proveedor());
            escondersubmenu();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            abrirFormularios(new Pantalla_hija_Categoria());
            escondersubmenu();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            abrirFormularios(new Pantalla_hija());
            escondersubmenu();
        }
    }
}
